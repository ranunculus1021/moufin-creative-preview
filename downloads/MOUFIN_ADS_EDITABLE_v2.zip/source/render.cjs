const path=require('node:path');const {Art,C}=require('./draw.cjs');
const base=path.resolve(__dirname,'..'),a=new Art(base);
function carousel(n,portrait=false){const h=portrait?1350:1080,d=portrait?84:0;a.start(`C0${n}-${portrait?'portrait':'square'}`,h,n===4?C.yellow:C.paper);a.header('',false);a.text(`${n} / 4`,996,88,28,C.muted,550,'P','right');
 if(n===1){a.head(['골든크로스,','찾을 수 있나요?'],82,225+d,105);a.quiz(536+d,{h:portrait?290:213});a.text('정답은 다음 장에',84,h-136,38,C.ink,650);a.arrow(927,h-112,66);a.footer('20·60일선 예시 · 가상 차트');}
 if(n===2){a.text('정답 A',84,194+d,37,C.green,750);a.head(['20일선이','60일선 위로.'],82,257+d,99);a.explanation(499+d,{h:portrait?315:214});a.text('아래에서 위로 교차하는 순간이에요.',84,h-153,37,C.ink,650);a.footer('20·60일선 예시 · 가상 차트 · 상승을 보장하지 않습니다');}
 if(n===3){a.head(['영상은 봤는데,','문제는 헷갈렸다면.'],82,226+d,86);a.steps(511+d,{gap:portrait?172:145});a.footer('머핀이 준비 중인 주식 학습 방식');}
 if(n===4){a.head(['주식 공부,','직접 풀어보세요.'],82,226+d,105);a.text('영상으로 배우고, 퀴즈로 확인하는 머핀',85,479+d,37,C.ink,550);a.image('mascot',639,552+d,337,290);a.text('개념 영상',84,599+d,44,C.ink,650);a.text('퀴즈',84,672+d,44,C.ink,650);a.text('차트 연습',84,745+d,44,C.ink,650);a.cta('머핀 체험하기',h-175);a.footer('공개 체험 페이지 · 앱 출시 준비 중');}
 a.save(`carousel-${portrait?'portrait':'square'}/C0${n}.png`);
}
function ad(n,story=false){const h=story?1920:1350,off=story?217:0,y=story?283:65;const dark=n===3;a.start(`AD0${n}-${story?'story':'feed'}`,h,dark?C.ink:n===5?C.light:C.paper);a.header('',dark,y);
 if(n===1){a.head(['골든크로스,','찾을 수 있나요?'],82,249+off,105);a.quiz(583+off,{h:245});a.text('머핀에서 정답과 해설을 확인하세요.',84,1037+off,36,C.ink,550);}
 if(n===2){a.head(['저장은 했는데,','기억나는 건?'],82,249+off,116);a.text('나중에 보려고 모아둔 주식 영상들.',85,537+off,38,C.muted,500);a.videoStack(658+off);a.text('오늘 본 개념, 한 문제로 확인해요.',84,1055+off,38,C.green,650);}
 if(n===3){a.head(['PER 검색했더니','EPS부터 모르겠다.'],82,248+off,88,C.paper);a.text('한 단어를 알려고 또 다른 단어를 검색 중.',85,474+off,33,'#E3D3C2',450);a.text('PER',84,661+off,184,C.yellow,700);a.arrow(501,756+off,99,C.paper);a.text('EPS?',687,684+off,116,C.paper,600);a.line(84,900+off,996,900+off,'#766050',2);a.text('어려운 말부터 하나씩 배워보세요.',84,990+off,38,C.paper,600);}
 if(n===4){a.head(['골든크로스가','나온 곳은?'],82,249+off,107);a.text('뜻을 안다면, 차트에서도 찾아볼까요?',84,512+off,36,C.muted,500);a.chart(84,670+off,912,267,{});a.text('20·60일선 예시 · 가상 차트',84,1002+off,27,C.muted,500);}
 if(n===5){a.head(['첫 강의만','세 번째.'],82,249+off,119);a.text('시작할 때마다 같은 영상만 보고 있다면.',84,545+off,36,C.muted,500);a.text('주식이란?',87,663+off,94,C.muted,450);a.text('주식이란?',87,793+off,94,C.muted,450);a.line(84,838+off,688,838+off,C.ink,3);a.text('이번엔 문제까지.',84,949+off,77,C.green,400,'Jua');}
 const yy=story?1431:1150;a.cta('머핀 체험하기',yy,dark);a.text('주식 학습 앱 · 출시 준비 중',84,yy+120,27,dark?C.paper:C.muted,500);a.save(`${story?'story':'feed'}/AD0${n}.png`);
}
function share(){a.start('share',630,C.yellow,1200);a.header();a.head(['주식 영상 다음엔,','직접 한 문제.'],82,210,90);a.text('영상 · 퀴즈 · 차트 연습',85,456,36,C.ink,600);a.image('mascot',855,220,270,282);a.footer('MOUFIN · 머핀  |  출시 준비 중');a.save('share/MOUFIN_SHARE.png');}
(async()=>{await a.load();const sample=process.argv.includes('--sample');for(const n of sample?[1,2]:[1,2,3,4])for(const p of sample?[false]:[false,true])carousel(n,p);if(!sample){for(let n=1;n<=5;n++)for(const s of [false,true])ad(n,s);share();}a.report();})();
