/* Native, editable typesetting and educational diagrams. MOUFIN refinement v2. */
const {createCanvas,loadImage,GlobalFonts}=require('@napi-rs/canvas');
const fs=require('node:fs'),path=require('node:path');
const C={paper:'#FFF9EC',ink:'#342018',green:'#236442',yellow:'#FFC447',muted:'#776253',line:'#DCCEB6',light:'#E4EFD9',white:'#FFFFFF'};
class Art {
 constructor(base){this.base=base;this.boxes=[];this.images={};GlobalFonts.registerFromPath(path.join(base,'assets/Jua-Regular.ttf'),'Jua');GlobalFonts.registerFromPath(path.join(base,'assets/PretendardVariable.ttf'),'P');}
 async load(){for(const [name,file] of Object.entries({logo:'MOUFIN-logo-cutout.png',mascot:'site-mascot.webp'}))this.images[name]=await loadImage(path.join(this.base,'assets',file));}
 start(id,h=1080,bg=C.paper,w=1080){this.id=id;this.w=w;this.h=h;this.canvas=createCanvas(w,h);this.c=this.canvas.getContext('2d');this.c.fillStyle=bg;this.c.fillRect(0,0,w,h);return this.canvas;}
 text(s,x,y,size=40,color=C.ink,weight=600,font='P',align='left'){
  const c=this.c;c.font=`${Math.round(weight/100)*100} ${size}px ${font}`;c.textBaseline='top';c.textAlign=align;c.fillStyle=color;const width=c.measureText(s).width;const left=align==='center'?x-width/2:align==='right'?x-width:x;
  this.boxes.push({asset:this.id,text:s,x:left,y,width,height:size,font,size,within:left>=30&&left+width<=this.w-30&&y>=0&&y+size<=this.h});c.fillText(s,x,y);return width;
 }
 head(rows,x,y,size=100,color=C.ink,gap=1.12){rows.forEach((s,i)=>this.text(s,x,y+i*size*gap,size,color,400,'Jua'));}
 line(x,y,xx,yy,color=C.line,width=2,dash=[]){const c=this.c;c.beginPath();c.strokeStyle=color;c.lineWidth=width;c.setLineDash(dash);c.moveTo(x,y);c.lineTo(xx,yy);c.stroke();c.setLineDash([]);}
 box(x,y,w,h,fill=C.paper,r=0,stroke=null){const c=this.c;c.beginPath();c.roundRect(x,y,w,h,r);c.fillStyle=fill;c.fill();if(stroke){c.strokeStyle=stroke;c.lineWidth=2;c.stroke();}}
 circle(x,y,r,fill,stroke=null,sw=3){const c=this.c;c.beginPath();c.arc(x,y,r,0,Math.PI*2);if(fill){c.fillStyle=fill;c.fill();}if(stroke){c.strokeStyle=stroke;c.lineWidth=sw;c.stroke();}}
 image(name,x,y,w,h){const im=this.images[name],s=Math.min(w/im.width,h/im.height);this.c.drawImage(im,x+(w-im.width*s)/2,y+(h-im.height*s)/2,im.width*s,im.height*s);}
 logo(y=55,dark=false,w=172){if(dark)this.box(72,y-5,w+20,w*.55+10,C.paper,10);this.image('logo',82,y,w,w*.55);}
 header(label='',dark=false,y=54){this.logo(y,dark);if(label)this.text(label,this.w-82,y+32,27,dark?C.paper:C.muted,600,'P','right');}
 arrow(x,y,l=46,color=C.ink){this.line(x,y,x+l,y,color,4);this.line(x+l-14,y-13,x+l,y,color,4);this.line(x+l-14,y+13,x+l,y,color,4);}
 footer(label='',page='',dark=false){const col=dark?'#E3D3C2':C.muted;this.text(label,84,this.h-56,24,col,500);if(page)this.text(page,this.w-84,this.h-56,24,col,500,'P','right');}
 cta(label,y,dark=false){this.box(82,y,this.w-164,92,dark?C.yellow:C.green,12);this.text(label,117,y+25,37,dark?C.ink:C.paper,700);this.arrow(this.w-188,y+46,44,dark?C.ink:C.paper);}
 chart(x,y,w,h,{up=true,highlight=false,labels=true,mini=false}={}){
  // Both traces have the same visible time span; 20/60 name the lookback periods.
  const labelW=labels?(mini?80:240):0,pw=w-labelW;
  const avg60=[[0,.57],[.2,.56],[.4,.55],[.6,.53],[.8,.51],[1,.49]];
  const avg20=up?[[0,.86],[.2,.79],[.4,.68],[.6,.43],[.8,.23],[1,.12]]:[[0,.13],[.2,.24],[.4,.36],[.6,.66],[.8,.81],[1,.88]];
  for(const f of [.25,.5,.75])this.line(x,y+h*f,x+pw,y+h*f,C.line,1.6);
  const plot=(a,col,sw,dash)=>{const c=this.c;c.beginPath();c.strokeStyle=col;c.lineWidth=sw;c.lineCap='round';c.lineJoin='round';c.setLineDash(dash);a.forEach(([xx,yy],i)=>i?c.lineTo(x+xx*pw,y+yy*h):c.moveTo(x+xx*pw,y+yy*h));c.stroke();c.setLineDash([]);};
  plot(avg60,C.muted,mini?5:6,[13,10]);plot(avg20,C.green,mini?8:10,[]);
  if(labels){this.text(mini?'20일':'20일 이동평균선',x+pw+15,y+avg20.at(-1)[1]*h-15,36,C.green,700);this.text(mini?'60일':'60일 이동평균선',x+pw+15,y+.49*h-15,36,C.muted,600);}
  if(highlight){const d0=avg20[2][1]-avg60[2][1],d1=avg20[3][1]-avg60[3][1],t=d0/(d0-d1),xx=.4+.2*t,yy=avg60[2][1]+(avg60[3][1]-avg60[2][1])*t;this.circle(x+xx*pw,y+yy*h,22,C.yellow,C.ink,3);this.circle(x+xx*pw,y+yy*h,5,C.ink);}
 }
 quiz(y,{h=230,label=true}={}){const widths=421;this.text('A',86,y,47,C.ink,750);this.text('B',580,y,47,C.ink,750);this.line(538,y,538,y+h+95,C.line,2);this.chart(85,y+74,widths,h,{up:true,mini:true});this.chart(579,y+74,widths,h,{up:false,mini:true});if(label)this.text('초록 실선 20일선 · 갈색 점선 60일선',84,y+h+116,29,C.muted,500);}
 explanation(y,{h=226}={}){this.chart(84,y,912,h,{highlight:true});this.text('20일선',84,y+h+56,38,C.green,750);this.text('최근 20거래일 종가의 평균',252,y+h+57,38,C.ink,500);this.text('60일선',84,y+h+115,38,C.muted,750);this.text('최근 60거래일 종가의 평균',252,y+h+116,38,C.ink,500);}
 steps(y,{dark=false,gap=148}={}){const col=dark?C.paper:C.ink;[['01','영상으로 배우고','이동평균선이 뭔지 알아보기'],['02','퀴즈로 확인하고','배운 개념으로 한 문제 풀기'],['03','차트에서 찾아보기','지난 차트에서 교차점 찾기']].forEach((r,i)=>{const yy=y+i*gap;this.text(r[0],84,yy+8,29,dark?C.yellow:C.green,700);this.head([r[1]],174,yy,57,col);this.text(r[2],175,yy+74,31,dark?'#D7C6B7':C.muted,500);if(i<2)this.line(174,yy+121,994,yy+121,dark?'#6C5546':C.line,2);});}
 videoStack(y){const data=[['이동평균선 쉽게 이해하기','나중에 볼 영상'],['PER, 이 숫자는 무슨 뜻?','나중에 볼 영상'],['주식 공부 어디서 시작할까','나중에 볼 영상']];data.forEach((r,i)=>{const xx=84+i*16,yy=y+i*121;this.box(xx,yy,880-i*16,104,i===2?C.light:'#F0E7D5',7);this.c.beginPath();this.c.moveTo(xx+31,yy+30);this.c.lineTo(xx+31,yy+73);this.c.lineTo(xx+64,yy+51);this.c.closePath();this.c.fillStyle=C.green;this.c.fill();this.text(r[0],xx+97,yy+21,33,C.ink,650);this.text(r[1],xx+97,yy+65,23,C.muted,450);});}
 save(rel){const p=path.join(this.base,rel);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,this.canvas.toBuffer('image/png'));}
 report(){const bad=this.boxes.filter(x=>!x.within);fs.writeFileSync(path.join(this.base,'evidence/layout-boxes.json'),JSON.stringify(this.boxes,null,2));console.log(JSON.stringify({texts:this.boxes.length,overflow:bad},null,2));if(bad.length)process.exitCode=1;}
}
module.exports={Art,C};
